--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.blog_user DROP CONSTRAINT fk_role_id;
ALTER TABLE ONLY public.comment DROP CONSTRAINT fk_post_id;
ALTER TABLE ONLY public.role DROP CONSTRAINT unique_role_id;
ALTER TABLE ONLY public.post DROP CONSTRAINT unique_post_id;
ALTER TABLE ONLY public.blog_user DROP CONSTRAINT unique_blog_user_role_id;
DROP TABLE public.role;
DROP TABLE public.post;
DROP TABLE public.comment;
DROP TABLE public.blog_user;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: blog_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_user (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    email character varying(255) NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    password character varying(255) NOT NULL
);


ALTER TABLE public.blog_user OWNER TO postgres;

--
-- Name: blog_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.blog_user ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.blog_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    created_at timestamp without time zone NOT NULL,
    id bigint NOT NULL,
    post_id bigint NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    comment_content text NOT NULL,
    posted_by character varying(255) NOT NULL
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.comment ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: post; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post (
    created_at timestamp without time zone NOT NULL,
    id bigint NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    author character varying(255) NOT NULL,
    content text NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.post OWNER TO postgres;

--
-- Name: post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.post ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.role OWNER TO postgres;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.role ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: blog_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.blog_user (id, role_id, email, first_name, last_name, password) OVERRIDING SYSTEM VALUE VALUES
	(1, 1, 'user1@gmail.com', 'user1', 'user1', '$2a$10$plDgIHSLauRpPqvcgxEq/u7zdK5ZvKL2.VeyDuAsYil53fPxxdgaC');


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.comment (created_at, id, post_id, updated_at, comment_content, posted_by) OVERRIDING SYSTEM VALUE VALUES
	('2024-08-03 12:59:57.69952', 1, 1, '2024-08-03 12:59:57.69952', 'masterClass wow', 'Nicolas');


--
-- Data for Name: post; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.post (created_at, id, updated_at, author, content, title) OVERRIDING SYSTEM VALUE VALUES
	('2024-08-03 12:59:43.468886', 1, '2024-08-03 12:59:43.468886', 'gogoanime', 'A Japannese Manga anime that focuses on secret agents carrying out secret missions', 'Darker than Black');


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.role (id, name) OVERRIDING SYSTEM VALUE VALUES
	(1, 'USER');


--
-- Name: blog_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_user_id_seq', 1, true);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comment_id_seq', 1, true);


--
-- Name: post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_id_seq', 1, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_id_seq', 1, true);


--
-- Name: blog_user unique_blog_user_role_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_user
    ADD CONSTRAINT unique_blog_user_role_id UNIQUE (role_id);


--
-- Name: post unique_post_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT unique_post_id UNIQUE (id);


--
-- Name: role unique_role_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT unique_role_id UNIQUE (id);


--
-- Name: comment fk_post_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fk_post_id FOREIGN KEY (post_id) REFERENCES public.post(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: blog_user fk_role_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_user
    ADD CONSTRAINT fk_role_id FOREIGN KEY (role_id) REFERENCES public.role(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

